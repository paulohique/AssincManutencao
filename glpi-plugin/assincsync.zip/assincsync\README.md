# Assinc Sync (GLPI Plugin)

Plugin para GLPI que registra uma **ação automática (cron)** responsável por detectar computadores **novos/alterados** e enviar para a sua **Python API** (incremental).

## O que ele faz

- Registra a ação automática `assincsync / trigger`.
- A cada execução:
  - Consulta `glpi_computers` por computadores com `date_mod`/`date_creation` maiores que o último cursor.
  - Envia somente os IDs para a Python API:
    - `POST ${PY_API_URL}/api/webhook/glpi/push?async=true`
    - Header: `X-Glpi-Webhook-Token: <token>`

> Observação: este plugin envia apenas **IDs**. A sua aplicação continua consultando o GLPI via API REST para buscar detalhes/componentes e fazer upsert no banco local.

## Instalação

1. Copie a pasta `assincsync` para o servidor do GLPI em `glpi/plugins/assincsync`.
2. No GLPI: **Setup → Plugins**, instale e habilite **Assinc Sync**.
3. Abra a configuração do plugin e preencha:
   - URL base da Python API (ex.: `http://seu-servidor:8000`)
   - Webhook token (deve bater com `GLPI_WEBHOOK_TOKEN` no backend)
  - (opcional) Lookback inicial e tamanho do lote

## Configurar o backend

Na Python API, configure no `.env`:

```env
GLPI_WEBHOOK_TOKEN=um_segredo_grande
```

E use o endpoint:
- `POST /api/webhook/glpi/push?async=true`

## Agendamento

No GLPI: **Setup → Automatic actions**
- Procure por `assincsync` / `trigger`
- Ajuste a frequência conforme necessário.
