<?php

class PluginAssincsyncCron {
   static function cronInfo($name) {
      switch ($name) {
         case 'trigger':
            return [
               'description' => 'Dispara o sync do Assinc Manutenções (chama a Python API).'
            ];
      }
      return [];
   }

   static function cronTrigger($task) {
      if (!class_exists('Config')) {
         return 0;
      }

      global $DB;
      if (!isset($DB)) {
         if (is_object($task)) {
            $task->log('AssincSync: DB não disponível');
         }
         return 0;
      }

      $cfg = Config::getConfigurationValues('plugin:assincsync');
      $baseUrl = isset($cfg['py_api_url']) ? trim($cfg['py_api_url']) : '';
      $token = isset($cfg['webhook_token']) ? trim($cfg['webhook_token']) : '';
      $timeout = isset($cfg['timeout_seconds']) ? intval($cfg['timeout_seconds']) : 15;
      $lastSuccessAt = isset($cfg['last_success_at']) ? trim($cfg['last_success_at']) : '';
      $initialLookbackMinutes = isset($cfg['initial_lookback_minutes']) ? intval($cfg['initial_lookback_minutes']) : 1440;
      $batchSize = isset($cfg['batch_size']) ? intval($cfg['batch_size']) : 200;
      if ($timeout <= 0) {
         $timeout = 15;
      }
      if ($initialLookbackMinutes <= 0) {
         $initialLookbackMinutes = 1440;
      }
      if ($batchSize <= 0) {
         $batchSize = 200;
      }

      if ($baseUrl === '' || $token === '') {
         if (is_object($task)) {
            $task->log('AssincSync: configure py_api_url e webhook_token em Setup > Plugins > Assinc Sync');
         }
         return 0;
      }

      // Cursor: se nunca rodou com sucesso, busca mudanças recentes.
      $since = $lastSuccessAt;
      if ($since === '') {
         $sinceTs = time() - ($initialLookbackMinutes * 60);
         $since = date('Y-m-d H:i:s', $sinceTs);
      }

      // Pega computadores criados/alterados desde $since.
      // Tabelas padrão do GLPI: glpi_computers.date_mod / glpi_computers.date_creation
      $esc = $since;
      if (method_exists($DB, 'escape')) {
         $esc = $DB->escape($since);
      } else {
         $esc = addslashes($since);
      }

      $sql = "SELECT id FROM glpi_computers WHERE (date_mod > '" . $esc . "' OR date_creation > '" . $esc . "') ORDER BY date_mod ASC LIMIT " . intval($batchSize);
      $res = $DB->query($sql);
      if (!$res) {
         if (is_object($task)) {
            $task->log('AssincSync: query glpi_computers falhou');
         }
         return 0;
      }

      $ids = [];
      while ($row = $DB->fetchAssoc($res)) {
         if (isset($row['id'])) {
            $ids[] = intval($row['id']);
         }
      }

      if (count($ids) === 0) {
         if (is_object($task)) {
            $task->log('AssincSync: nenhum computador novo/alterado desde ' . $since);
         }
         return 1;
      }

      $url = rtrim($baseUrl, '/') . '/api/webhook/glpi/push?async=true';

      $ch = curl_init($url);
      if ($ch === false) {
         return 0;
      }

      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_HTTPHEADER, [
         'Content-Type: application/json',
         'X-Glpi-Webhook-Token: ' . $token,
      ]);
      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
         'computer_ids' => $ids,
      ]));
      curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, min(5, $timeout));

      $body = curl_exec($ch);
      $err = curl_error($ch);
      $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
      curl_close($ch);

      if ($err) {
         if (is_object($task)) {
            $task->log('AssincSync: erro ao chamar webhook: ' . $err);
         }
         return 0;
      }

      if ($code >= 200 && $code < 300) {
         if (is_object($task)) {
            $task->log('AssincSync: push OK (' . $code . ') ids=' . count($ids) . ' since=' . $since);
         }

         // Só avança o cursor se não bateu no limite (para evitar perder itens).
         if (count($ids) < $batchSize) {
            Config::setConfigurationValues('plugin:assincsync', [
               'last_success_at' => date('Y-m-d H:i:s'),
            ]);
         }

         return 1;
      }

      if (is_object($task)) {
         $snippet = is_string($body) ? substr($body, 0, 500) : '';
         $task->log('AssincSync: webhook falhou HTTP ' . $code . ' body=' . $snippet);
      }

      return 0;
   }
}
